Notes about board/common directory:

Because the mx6dq and mx6sdl chips share the same boards, board code common to
those chips is placed in this directory.

Board code for the mx6sl goes under in the board directories under board/mx6sl,
as there is very little shared with the mx6dq and mx6sdl since they don't use
the same boards.


